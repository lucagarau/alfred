import alfred
bot = alfred.Alfred("6295663581:AAHvsPdyPa4vI6XBDSKu3sbDv9jtjUmg5GM",186867781)
bot.send_file(R"C:\Users\luca-\OneDrive\Data\progetti\python\alfred\README.md")